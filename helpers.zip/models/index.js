module.exports = {
    ProductsApi: require('./products/products.api')
}